#ifndef __FAKE_LIBINTL_H
#define __FAKE_LIBINTL_H

#define _(X) (X)

#endif
